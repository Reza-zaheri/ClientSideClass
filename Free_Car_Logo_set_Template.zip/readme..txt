
------- free-psd-templates.com --------

Hello! Thanks a lot for downloading, I hope it will be of service to you.
--------------------------------------

-----------------Free Fonts------------------
Urae Nium
https://www.dafont.com/urae-nium.font

NEXT ART
https://www.dafont.com/next-art.font

Plateia
https://www.dafont.com/plateia.font

Bebas Neue
https://www.dafont.com/bebas-neue.font

Open Sans Condensed
https://fonts.google.com/specimen/Open+Sans+Condensed




To use free patterns set, just open the included Ai,EPS, PSD or PNG file. 
in relevant programs: Ai (Adobe Illustration) PSD (Adobe Photoshop).



----------------------------------------------------------------------------------
Our team thanks you again for  purchasing.

We are always happy to help you. 